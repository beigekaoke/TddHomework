package com.flagship.startup.utils;

public class ConstrantString {
	
	public static final String CSV_EXTENSION = "csv";

	public static final String TYPE_FILE = "FILE";
	
	public static final String TYPE_DATA_BASE = "DATABASE";
}
